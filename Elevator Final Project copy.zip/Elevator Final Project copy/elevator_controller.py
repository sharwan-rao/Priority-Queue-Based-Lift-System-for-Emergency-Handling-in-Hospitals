"""
ElevatorController: Manages the elevator's current floor, direction, and motion logic.
"""


class ElevatorController:
    def __init__(self, num_floors=10, start_floor=1):
        self.num_floors = num_floors
        self.current_floor = start_floor
        self.direction = "IDLE"  # "UP", "DOWN", or "IDLE"
        self.is_moving = False
        self.target_floor = None
        
    def get_current_floor(self):
        return self.current_floor
    
    def get_direction(self):
        return self.direction
    
    def set_direction(self, direction):
        """Set direction: 'UP', 'DOWN', or 'IDLE'"""
        self.direction = direction
    
    def move_to_floor(self, target_floor):
        """Set target floor and determine direction"""
        if target_floor == self.current_floor:
            self.direction = "IDLE"
            self.target_floor = None
            return
        
        self.target_floor = target_floor
        if target_floor > self.current_floor:
            self.direction = "UP"
        else:
            self.direction = "DOWN"
        self.is_moving = True
    
    def step(self):
        """Simulate one step of elevator movement"""
        if self.target_floor is None:
            self.is_moving = False
            self.direction = "IDLE"
            return False
        
        if self.current_floor == self.target_floor:
            self.is_moving = False
            self.direction = "IDLE"
            self.target_floor = None
            return True  # Arrived at target
        
        if self.direction == "UP":
            self.current_floor += 1
        elif self.direction == "DOWN":
            self.current_floor -= 1
        
        return False  # Still moving
    
    def is_at_floor(self, floor):
        """Check if elevator is at a specific floor"""
        return self.current_floor == floor
    
    def get_next_floor(self):
        """Get the next floor the elevator will reach"""
        if self.target_floor is None:
            return None
        if self.direction == "UP":
            return min(self.current_floor + 1, self.target_floor)
        elif self.direction == "DOWN":
            return max(self.current_floor - 1, self.target_floor)
        return None




