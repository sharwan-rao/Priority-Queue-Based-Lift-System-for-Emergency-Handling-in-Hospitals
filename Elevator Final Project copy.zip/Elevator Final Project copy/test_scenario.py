"""
Test script for Section 7 Comprehensive Scenario:
- Start at Floor 3 (Up)
- Normal requests: 4↑, 6↓, 7↑
- Add emergencies: (4→10) and (2→1)
- Expected: Serve (4→10) first (Group A), then (2→1) (Group B), then resume normal requests
"""

from elevator_system import ElevatorSystem
import time


def test_section_7_scenario():
    """Test the comprehensive scenario from Section 7"""
    print("=" * 60)
    print("Section 7 Comprehensive Scenario Test")
    print("=" * 60)
    print()
    
    # Initialize elevator at Floor 3, Direction UP
    elevator = ElevatorSystem(num_floors=10, start_floor=3, start_direction="UP")
    print(f"Initial state: Floor {elevator.controller.get_current_floor()}, "
          f"Direction: {elevator.controller.get_direction()}")
    print()
    
    # Add normal requests
    print("Adding normal requests:")
    elevator.add_external_request(4, "UP")  # 4↑
    print("  - External UP request at Floor 4")
    elevator.add_external_request(6, "DOWN")  # 6↓
    print("  - External DOWN request at Floor 6")
    elevator.add_external_request(7, "UP")  # 7↑
    print("  - External UP request at Floor 7")
    print()
    
    # Add emergency requests
    print("Adding emergency requests:")
    elevator.add_emergency_request(4, 10)  # (4→10)
    print("  - Emergency: Floor 4 → Floor 10")
    elevator.add_emergency_request(2, 1)  # (2→1)
    print("  - Emergency: Floor 2 → Floor 1")
    print()
    
    print("Expected behavior:")
    print("  1. Emergency mode activated - normal requests paused")
    print("  2. Go to Floor 4 (pickup for emergency 4→10) - Group A")
    print("  3. Go to Floor 10 (destination for emergency 4→10)")
    print("  4. Reverse direction, go to Floor 2 (pickup for emergency 2→1) - Group B")
    print("  5. Go to Floor 1 (destination for emergency 2→1)")
    print("  6. Resume normal requests: Floor 6 (DOWN), Floor 7 (UP)")
    print()
    print("=" * 60)
    print("Simulation:")
    print("=" * 60)
    print()
    
    # Run simulation
    step_count = 0
    max_steps = 50  # Prevent infinite loops
    
    while step_count < max_steps:
        step_count += 1
        arrived, message = elevator.update()
        
        if message:
            status = elevator.get_status()
            print(f"Step {step_count}: {message}")
            print(f"  Status: Floor {status['floor']}, Direction: {status['direction']}, "
                  f"Emergency Mode: {status['emergency_mode']}")
            
            # Check if we've completed all requests
            if (not status['emergency_mode'] and 
                not elevator.queue_manager.has_normal_requests() and
                elevator.controller.get_direction() == "IDLE"):
                print()
                print("All requests completed!")
                break
        
        time.sleep(0.1)  # Small delay for readability
    
    print()
    print("=" * 60)
    print("Test completed")
    print("=" * 60)


if __name__ == "__main__":
    test_section_7_scenario()




