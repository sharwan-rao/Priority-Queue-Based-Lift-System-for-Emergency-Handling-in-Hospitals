"""
QueueManager: Stores and manages internal, external, and emergency requests.
"""


class QueueManager:
    def __init__(self, num_floors=10):
        self.num_floors = num_floors
        # Internal requests: floor numbers where someone pressed button inside
        self.internal_requests = set()
        # External requests: (floor, direction) tuples
        self.external_up_requests = set()  # Floors requesting UP
        self.external_down_requests = set()  # Floors requesting DOWN
        # Emergency requests: (from_floor, to_floor) tuples
        self.emergency_requests = []
        # Paused normal requests (saved when emergency occurs)
        self.paused_internal = set()
        self.paused_external_up = set()
        self.paused_external_down = set()
        self.is_paused = False
        
    def add_internal_request(self, floor):
        """Add an internal request (button pressed inside elevator)"""
        if 1 <= floor <= self.num_floors:
            if self.is_paused:
                self.paused_internal.add(floor)
            else:
                self.internal_requests.add(floor)
    
    def add_external_request(self, floor, direction):
        """Add an external request (UP or DOWN button pressed)"""
        if 1 <= floor <= self.num_floors:
            if self.is_paused:
                if direction == "UP":
                    self.paused_external_up.add(floor)
                else:
                    self.paused_external_down.add(floor)
            else:
                if direction == "UP":
                    self.external_up_requests.add(floor)
                else:
                    self.external_down_requests.add(floor)
    
    def add_emergency_request(self, from_floor, to_floor):
        """Add an emergency request"""
        if 1 <= from_floor <= self.num_floors and 1 <= to_floor <= self.num_floors:
            self.emergency_requests.append((from_floor, to_floor))
    
    def pause_normal_requests(self):
        """Pause all normal requests and save them"""
        if not self.is_paused:
            self.paused_internal = self.internal_requests.copy()
            self.paused_external_up = self.external_up_requests.copy()
            self.paused_external_down = self.external_down_requests.copy()
            self.internal_requests.clear()
            self.external_up_requests.clear()
            self.external_down_requests.clear()
            self.is_paused = True
    
    def resume_normal_requests(self):
        """Resume normal requests after emergency is handled"""
        if self.is_paused:
            self.internal_requests = self.paused_internal.copy()
            self.external_up_requests = self.paused_external_up.copy()
            self.external_down_requests = self.paused_external_down.copy()
            self.paused_internal.clear()
            self.paused_external_up.clear()
            self.paused_external_down.clear()
            self.is_paused = False
    
    def remove_internal_request(self, floor):
        """Remove an internal request (elevator reached floor)"""
        self.internal_requests.discard(floor)
    
    def remove_external_request(self, floor, direction):
        """Remove an external request (elevator reached floor)"""
        if direction == "UP":
            self.external_up_requests.discard(floor)
        else:
            self.external_down_requests.discard(floor)
    
    def remove_emergency_request(self, from_floor, to_floor):
        """Remove an emergency request"""
        if (from_floor, to_floor) in self.emergency_requests:
            self.emergency_requests.remove((from_floor, to_floor))
    
    def has_emergency_requests(self):
        """Check if there are any emergency requests"""
        return len(self.emergency_requests) > 0
    
    def has_normal_requests(self):
        """Check if there are any normal requests"""
        return (len(self.internal_requests) > 0 or 
                len(self.external_up_requests) > 0 or 
                len(self.external_down_requests) > 0)
    
    def get_all_requests(self):
        """Get all current normal requests for debugging"""
        return {
            'internal': self.internal_requests,
            'external_up': self.external_up_requests,
            'external_down': self.external_down_requests
        }




