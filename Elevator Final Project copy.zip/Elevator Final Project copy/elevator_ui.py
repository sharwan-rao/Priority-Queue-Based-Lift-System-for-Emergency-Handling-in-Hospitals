"""
Elevator UI: Tkinter interface with interactive buttons and status panel.
Modern web-style design.
"""

import tkinter as tk
from tkinter import ttk, messagebox
from elevator_system import ElevatorSystem


class ElevatorUI:
    def __init__(self, root, num_floors=10, start_floor=3, start_direction="UP"):
        self.root = root
        self.root.title("Emergency Elevator Algorithm Enhancement")
        self.root.geometry("1100x800")
        
        # Modern color scheme
        self.colors = {
            'bg': '#f5f7fa',
            'card_bg': '#ffffff',
            'primary': '#4a90e2',
            'primary_hover': '#357abd',
            'success': '#52c41a',
            'danger': '#ff4d4f',
            'warning': '#faad14',
            'text': '#262626',
            'text_light': '#8c8c8c',
            'border': '#d9d9d9',
            'shadow': '#e8e8e8',
            'emergency': '#ff1744',
            'up': '#52c41a',
            'down': '#1890ff',
            'idle': '#8c8c8c'
        }
        
        # Configure root background
        self.root.configure(bg=self.colors['bg'])
        
        self.num_floors = num_floors
        self.elevator = ElevatorSystem(num_floors, start_floor, start_direction)
        
        # UI update interval (milliseconds)
        self.update_interval = 500  # 500ms = 0.5 seconds per floor movement
        
        self.setup_styles()
        self.setup_ui()
        self.start_simulation()
    
    def setup_styles(self):
        """Configure modern ttk styles"""
        style = ttk.Style()
        style.theme_use('clam')
        
        # Configure styles
        style.configure('Card.TFrame', background=self.colors['card_bg'], relief='flat')
        style.configure('Card.TLabelframe', background=self.colors['card_bg'], 
                      borderwidth=1, relief='flat', bordercolor=self.colors['border'])
        style.configure('Card.TLabelframe.Label', background=self.colors['card_bg'],
                       foreground=self.colors['text'], font=('Segoe UI', 11, 'bold'))
        
        # Modern button styles
        style.configure('Primary.TButton', 
                       background=self.colors['primary'],
                       foreground='white',
                       borderwidth=0,
                       focuscolor='none',
                       font=('Segoe UI', 9),
                       padding=(12, 6))
        style.map('Primary.TButton',
                 background=[('active', self.colors['primary_hover']),
                            ('pressed', self.colors['primary_hover'])])
        
        style.configure('Up.TButton',
                       background=self.colors['up'],
                       foreground='white',
                       borderwidth=0,
                       focuscolor='none',
                       font=('Segoe UI', 10, 'bold'),
                       padding=(8, 4))
        style.map('Up.TButton',
                 background=[('active', '#73d13d')])
        
        style.configure('Down.TButton',
                       background=self.colors['down'],
                       foreground='white',
                       borderwidth=0,
                       focuscolor='none',
                       font=('Segoe UI', 10, 'bold'),
                       padding=(8, 4))
        style.map('Down.TButton',
                 background=[('active', '#40a9ff')])
        
        style.configure('Emergency.TButton',
                       background=self.colors['danger'],
                       foreground='white',
                       borderwidth=0,
                       focuscolor='none',
                       font=('Segoe UI', 9, 'bold'),
                       padding=(10, 5))
        style.map('Emergency.TButton',
                 background=[('active', '#ff7875')])
        
        style.configure('Floor.TButton',
                       background='white',
                       foreground=self.colors['text'],
                       borderwidth=1,
                       relief='solid',
                       bordercolor=self.colors['border'],
                       focuscolor='none',
                       font=('Segoe UI', 10, 'bold'),
                       padding=(8, 8))
        style.map('Floor.TButton',
                 background=[('active', self.colors['primary']),
                            ('active', 'white')],
                 foreground=[('active', 'white')])
        
        # Status label style
        style.configure('Status.TLabel',
                       background=self.colors['card_bg'],
                       foreground=self.colors['text'],
                       font=('Segoe UI', 12, 'bold'),
                       padding=(10, 8))
        
        style.configure('StatusValue.TLabel',
                       background=self.colors['card_bg'],
                       font=('Segoe UI', 14, 'bold'),
                       padding=(10, 8))
        
    def setup_ui(self):
        """Create the UI components"""
        # Main container with padding
        main_frame = tk.Frame(self.root, bg=self.colors['bg'], padx=15, pady=15)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        title_frame = tk.Frame(main_frame, bg=self.colors['bg'])
        title_frame.pack(fill=tk.X, pady=(0, 15))
        title_label = tk.Label(title_frame, 
                              text="🚇 Emergency Elevator Control System",
                              font=('Segoe UI', 20, 'bold'),
                              bg=self.colors['bg'],
                              fg=self.colors['text'])
        title_label.pack()
        
        # Status Panel - Card style
        status_card = tk.Frame(main_frame, bg=self.colors['card_bg'], relief='flat', 
                              highlightbackground=self.colors['border'], highlightthickness=1)
        status_card.pack(fill=tk.X, pady=(0, 15))
        
        status_inner = tk.Frame(status_card, bg=self.colors['card_bg'], padx=20, pady=15)
        status_inner.pack(fill=tk.X)
        
        tk.Label(status_inner, text="Status Panel", 
                font=('Segoe UI', 12, 'bold'),
                bg=self.colors['card_bg'],
                fg=self.colors['text']).pack(anchor=tk.W, pady=(0, 10))
        
        status_content = tk.Frame(status_inner, bg=self.colors['card_bg'])
        status_content.pack(fill=tk.X)
        
        self.status_floor = tk.StringVar(value=f"{self.elevator.controller.get_current_floor()}")
        self.status_direction = tk.StringVar(value=f"{self.elevator.controller.get_direction()}")
        self.status_emergency = tk.StringVar(value="OFF")
        
        # Floor status
        floor_frame = tk.Frame(status_content, bg=self.colors['card_bg'])
        floor_frame.pack(side=tk.LEFT, padx=20)
        tk.Label(floor_frame, text="Current Floor", 
                font=('Segoe UI', 10),
                bg=self.colors['card_bg'],
                fg=self.colors['text_light']).pack()
        floor_value = tk.Label(floor_frame, textvariable=self.status_floor,
                              font=('Segoe UI', 24, 'bold'),
                              bg=self.colors['card_bg'],
                              fg=self.colors['primary'])
        floor_value.pack()
        
        # Direction status
        direction_frame = tk.Frame(status_content, bg=self.colors['card_bg'])
        direction_frame.pack(side=tk.LEFT, padx=20)
        tk.Label(direction_frame, text="Direction", 
                font=('Segoe UI', 10),
                bg=self.colors['card_bg'],
                fg=self.colors['text_light']).pack()
        direction_value = tk.Label(direction_frame, textvariable=self.status_direction,
                                  font=('Segoe UI', 24, 'bold'),
                                  bg=self.colors['card_bg'],
                                  fg=self.colors['idle'])
        direction_value.pack()
        self.direction_label = direction_value
        
        # Emergency status
        emergency_frame = tk.Frame(status_content, bg=self.colors['card_bg'])
        emergency_frame.pack(side=tk.LEFT, padx=20)
        tk.Label(emergency_frame, text="Emergency Mode", 
                font=('Segoe UI', 10),
                bg=self.colors['card_bg'],
                fg=self.colors['text_light']).pack()
        emergency_value = tk.Label(emergency_frame, textvariable=self.status_emergency,
                                  font=('Segoe UI', 20, 'bold'),
                                  bg=self.colors['card_bg'],
                                  fg=self.colors['text_light'])
        emergency_value.pack()
        self.emergency_label = emergency_value
        
        # Content area with three columns
        content_frame = tk.Frame(main_frame, bg=self.colors['bg'])
        content_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 15))
        
        # External Buttons Frame (UP/DOWN buttons for each floor)
        external_card = tk.Frame(content_frame, bg=self.colors['card_bg'], relief='flat',
                                highlightbackground=self.colors['border'], highlightthickness=1)
        external_card.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        external_inner = tk.Frame(external_card, bg=self.colors['card_bg'], padx=15, pady=15)
        external_inner.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(external_inner, text="Call Elevator", 
                font=('Segoe UI', 12, 'bold'),
                bg=self.colors['card_bg'],
                fg=self.colors['text']).pack(anchor=tk.W, pady=(0, 10))
        
        # Header row
        header_frame = tk.Frame(external_inner, bg=self.colors['card_bg'])
        header_frame.pack(fill=tk.X, pady=(0, 5))
        tk.Label(header_frame, text="Floor", font=('Segoe UI', 9, 'bold'),
                bg=self.colors['card_bg'], fg=self.colors['text_light'], width=8).pack(side=tk.LEFT, padx=5)
        tk.Label(header_frame, text="UP", font=('Segoe UI', 9, 'bold'),
                bg=self.colors['card_bg'], fg=self.colors['text_light']).pack(side=tk.LEFT, padx=5)
        tk.Label(header_frame, text="DOWN", font=('Segoe UI', 9, 'bold'),
                bg=self.colors['card_bg'], fg=self.colors['text_light']).pack(side=tk.LEFT, padx=5)
        
        # Scrollable frame for buttons
        canvas = tk.Canvas(external_inner, bg=self.colors['card_bg'], highlightthickness=0, height=400)
        scrollbar = ttk.Scrollbar(external_inner, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg=self.colors['card_bg'])
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        self.external_up_buttons = {}
        self.external_down_buttons = {}
        
        for floor in range(self.num_floors, 0, -1):
            row_frame = tk.Frame(scrollable_frame, bg=self.colors['card_bg'])
            row_frame.pack(fill=tk.X, pady=3)
            
            floor_label = tk.Label(row_frame, text=f"F{floor}", 
                                   font=('Segoe UI', 10),
                                   bg=self.colors['card_bg'],
                                   fg=self.colors['text'],
                                   width=8, anchor='w')
            floor_label.pack(side=tk.LEFT, padx=5)
            
            up_btn = ttk.Button(row_frame, text="↑", style='Up.TButton',
                              command=lambda f=floor: self.handle_external_up(f))
            up_btn.pack(side=tk.LEFT, padx=5)
            self.external_up_buttons[floor] = up_btn
            
            down_btn = ttk.Button(row_frame, text="↓", style='Down.TButton',
                                command=lambda f=floor: self.handle_external_down(f))
            down_btn.pack(side=tk.LEFT, padx=5)
            self.external_down_buttons[floor] = down_btn
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Internal Buttons Frame (Floor selection inside elevator)
        internal_card = tk.Frame(content_frame, bg=self.colors['card_bg'], relief='flat',
                                highlightbackground=self.colors['border'], highlightthickness=1)
        internal_card.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        internal_inner = tk.Frame(internal_card, bg=self.colors['card_bg'], padx=15, pady=15)
        internal_inner.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(internal_inner, text="Select Floor", 
                font=('Segoe UI', 12, 'bold'),
                bg=self.colors['card_bg'],
                fg=self.colors['text']).pack(anchor=tk.W, pady=(0, 10))
        
        # Create grid of floor buttons
        buttons_frame = tk.Frame(internal_inner, bg=self.colors['card_bg'])
        buttons_frame.pack(fill=tk.BOTH, expand=True)
        
        cols = 4
        for i, floor in enumerate(range(self.num_floors, 0, -1)):
            row = i // cols
            col = i % cols
            btn = ttk.Button(buttons_frame, text=str(floor), style='Floor.TButton',
                           command=lambda f=floor: self.handle_internal_request(f))
            btn.grid(row=row, column=col, padx=4, pady=4, sticky='nsew')
        
        # Configure grid weights
        for i in range(cols):
            buttons_frame.columnconfigure(i, weight=1)
        for i in range((self.num_floors + cols - 1) // cols):
            buttons_frame.rowconfigure(i, weight=1)
        
        # Emergency Buttons Frame
        emergency_card = tk.Frame(content_frame, bg=self.colors['card_bg'], relief='flat',
                                  highlightbackground=self.colors['border'], highlightthickness=1)
        emergency_card.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        emergency_inner = tk.Frame(emergency_card, bg=self.colors['card_bg'], padx=15, pady=15)
        emergency_inner.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(emergency_inner, text="Emergency Requests", 
                font=('Segoe UI', 12, 'bold'),
                bg=self.colors['card_bg'],
                fg=self.colors['text']).pack(anchor=tk.W, pady=(0, 10))
        
        tk.Label(emergency_inner, text="From → To", 
                font=('Segoe UI', 9),
                bg=self.colors['card_bg'],
                fg=self.colors['text_light']).pack(anchor=tk.W, pady=(0, 5))
        
        # Header row
        header_frame = tk.Frame(emergency_inner, bg=self.colors['card_bg'])
        header_frame.pack(fill=tk.X, pady=(0, 5))
        tk.Label(header_frame, text="From", font=('Segoe UI', 9, 'bold'),
                bg=self.colors['card_bg'], fg=self.colors['text_light']).pack(side=tk.LEFT, padx=2)
        tk.Label(header_frame, text="To", font=('Segoe UI', 9, 'bold'),
                bg=self.colors['card_bg'], fg=self.colors['text_light']).pack(side=tk.LEFT, padx=2)
        tk.Label(header_frame, text="Action", font=('Segoe UI', 9, 'bold'),
                bg=self.colors['card_bg'], fg=self.colors['text_light']).pack(side=tk.LEFT, padx=2)
        
        # Scrollable frame for emergency buttons
        em_canvas = tk.Canvas(emergency_inner, bg=self.colors['card_bg'], highlightthickness=0, height=400)
        em_scrollbar = ttk.Scrollbar(emergency_inner, orient="vertical", command=em_canvas.yview)
        em_scrollable_frame = tk.Frame(em_canvas, bg=self.colors['card_bg'])
        
        em_scrollable_frame.bind(
            "<Configure>",
            lambda e: em_canvas.configure(scrollregion=em_canvas.bbox("all"))
        )
        
        em_canvas.create_window((0, 0), window=em_scrollable_frame, anchor="nw")
        em_canvas.configure(yscrollcommand=em_scrollbar.set)
        
        self.emergency_from_vars = {}
        self.emergency_to_vars = {}
        self.emergency_buttons = {}
        
        for i, floor in enumerate(range(self.num_floors, 0, -1)):
            row_frame = tk.Frame(em_scrollable_frame, bg=self.colors['card_bg'])
            row_frame.pack(fill=tk.X, pady=3)
            
            # From floor dropdown
            from_var = tk.StringVar(value=str(floor))
            from_combo = ttk.Combobox(row_frame, textvariable=from_var, width=6, 
                                     values=[str(f) for f in range(1, self.num_floors + 1)], 
                                     state="readonly", font=('Segoe UI', 9))
            from_combo.pack(side=tk.LEFT, padx=2)
            self.emergency_from_vars[floor] = from_var
            
            # Arrow
            tk.Label(row_frame, text="→", font=('Segoe UI', 10),
                    bg=self.colors['card_bg'], fg=self.colors['text_light']).pack(side=tk.LEFT, padx=2)
            
            # To floor dropdown
            to_var = tk.StringVar(value=str(min(floor + 1, self.num_floors)))
            to_combo = ttk.Combobox(row_frame, textvariable=to_var, width=6,
                                  values=[str(f) for f in range(1, self.num_floors + 1)], 
                                  state="readonly", font=('Segoe UI', 9))
            to_combo.pack(side=tk.LEFT, padx=2)
            self.emergency_to_vars[floor] = to_var
            
            # Emergency button
            btn = ttk.Button(row_frame, text="🚨", style='Emergency.TButton',
                           command=lambda f=floor: self.handle_emergency_request(f))
            btn.pack(side=tk.LEFT, padx=5)
            self.emergency_buttons[floor] = btn
        
        em_canvas.pack(side="left", fill="both", expand=True)
        em_scrollbar.pack(side="right", fill="y")
        
        # Log/Info Panel
        log_card = tk.Frame(main_frame, bg=self.colors['card_bg'], relief='flat',
                           highlightbackground=self.colors['border'], highlightthickness=1)
        log_card.pack(fill=tk.BOTH, expand=True)
        
        log_inner = tk.Frame(log_card, bg=self.colors['card_bg'], padx=15, pady=15)
        log_inner.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(log_inner, text="Activity Log", 
                font=('Segoe UI', 12, 'bold'),
                bg=self.colors['card_bg'],
                fg=self.colors['text']).pack(anchor=tk.W, pady=(0, 10))
        
        log_container = tk.Frame(log_inner, bg=self.colors['card_bg'])
        log_container.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_container, height=8, wrap=tk.WORD,
                               font=('Consolas', 10),
                               bg='#fafafa',
                               fg=self.colors['text'],
                               relief='flat',
                               borderwidth=1,
                               highlightthickness=1,
                               highlightbackground=self.colors['border'],
                               padx=10, pady=10)
        log_scrollbar = ttk.Scrollbar(log_container, orient=tk.VERTICAL, command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=log_scrollbar.set)
        
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        log_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Initial log message
        self.log("Elevator system initialized")
        self.log(f"Starting at Floor {self.elevator.controller.get_current_floor()}, Direction: {self.elevator.controller.get_direction()}")
    
    def log(self, message):
        """Add a message to the log"""
        self.log_text.insert(tk.END, f"{message}\n")
        self.log_text.see(tk.END)
    
    def handle_external_up(self, floor):
        """Handle external UP button press"""
        if not self.elevator.emergency_handler.is_emergency_mode():
            self.elevator.add_external_request(floor, "UP")
            self.log(f"External UP request added for Floor {floor}")
        else:
            self.log(f"External UP request for Floor {floor} - PAUSED (Emergency Mode Active)")
    
    def handle_external_down(self, floor):
        """Handle external DOWN button press"""
        if not self.elevator.emergency_handler.is_emergency_mode():
            self.elevator.add_external_request(floor, "DOWN")
            self.log(f"External DOWN request added for Floor {floor}")
        else:
            self.log(f"External DOWN request for Floor {floor} - PAUSED (Emergency Mode Active)")
    
    def handle_internal_request(self, floor):
        """Handle internal floor button press"""
        if not self.elevator.emergency_handler.is_emergency_mode():
            self.elevator.add_internal_request(floor)
            self.log(f"Internal request added for Floor {floor}")
        else:
            self.log(f"Internal request for Floor {floor} - PAUSED (Emergency Mode Active)")
    
    def handle_emergency_request(self, floor_index):
        """Handle emergency button press"""
        from_floor = int(self.emergency_from_vars[floor_index].get())
        to_floor = int(self.emergency_to_vars[floor_index].get())
        
        if from_floor == to_floor:
            messagebox.showwarning("Invalid Request", "From floor and To floor cannot be the same!")
            return
        
        self.elevator.add_emergency_request(from_floor, to_floor)
        self.log(f"*** EMERGENCY REQUEST: Floor {from_floor} → Floor {to_floor} ***")
        self.log("Emergency mode activated - All normal requests paused")
    
    def update_status(self):
        """Update the status panel"""
        status = self.elevator.get_status()
        self.status_floor.set(str(status['floor']))
        
        direction = status['direction']
        self.status_direction.set(direction)
        
        # Update direction color
        if direction == "UP":
            self.direction_label.config(fg=self.colors['up'])
        elif direction == "DOWN":
            self.direction_label.config(fg=self.colors['down'])
        else:
            self.direction_label.config(fg=self.colors['idle'])
        
        # Update emergency status
        if status['emergency_mode']:
            self.status_emergency.set(f"ON ({status['emergency_count']})")
            self.emergency_label.config(fg=self.colors['emergency'])
        else:
            self.status_emergency.set("OFF")
            self.emergency_label.config(fg=self.colors['text_light'])
    
    def start_simulation(self):
        """Start the simulation loop"""
        def simulation_step():
            arrived, message = self.elevator.update()
            if message:
                self.log(message)
            self.update_status()
            self.root.after(self.update_interval, simulation_step)
        
        self.root.after(self.update_interval, simulation_step)


def main():
    root = tk.Tk()
    # Start at Floor 3, Direction UP (as per Section 7 scenario)
    app = ElevatorUI(root, num_floors=10, start_floor=3, start_direction="UP")
    root.mainloop()


if __name__ == "__main__":
    main()

