"""
Main entry point for the Emergency Elevator Algorithm Enhancement simulation.
"""

from elevator_ui import main

if __name__ == "__main__":
    main()




